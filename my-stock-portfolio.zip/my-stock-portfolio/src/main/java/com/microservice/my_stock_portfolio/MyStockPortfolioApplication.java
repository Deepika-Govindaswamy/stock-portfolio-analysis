package com.microservice.my_stock_portfolio;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class MyStockPortfolioApplication {

	public static void main(String[] args) {
		SpringApplication.run(MyStockPortfolioApplication.class, args);
	}

}
