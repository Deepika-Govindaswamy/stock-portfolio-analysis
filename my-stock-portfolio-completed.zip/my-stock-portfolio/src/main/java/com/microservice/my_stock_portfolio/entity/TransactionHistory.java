package com.microservice.my_stock_portfolio.entity;

import jakarta.persistence.*;
import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;

import java.time.Instant;

@Data
@Entity
@NoArgsConstructor
@AllArgsConstructor
@Builder
public class TransactionHistory {

    @Id
    @GeneratedValue(strategy = GenerationType.UUID)
    private String transactionId;

    private String investorId;

    @Enumerated(EnumType.STRING)
    private TransactionType transactionType;

    private String stockSymbol;

    private Long quantity;

    private Double stockPrice;

    private Instant transactionCreatedAt;
}
