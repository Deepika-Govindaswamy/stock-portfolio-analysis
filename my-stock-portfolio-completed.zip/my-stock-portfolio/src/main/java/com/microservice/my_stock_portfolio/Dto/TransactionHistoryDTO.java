package com.microservice.my_stock_portfolio.Dto;

public record TransactionHistoryDTO (String investorId, Long quantity, Double currentPrice) {
}
