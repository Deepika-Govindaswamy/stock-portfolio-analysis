package com.microservice.my_stock_portfolio.controller;

import com.microservice.my_stock_portfolio.Dto.ResponseDTO;
import com.microservice.my_stock_portfolio.service.HandleTransaction;
import lombok.RequiredArgsConstructor;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;

@RestController
@RequiredArgsConstructor
@RequestMapping ("/portfolio")
public class createPortfolio {

    private final HandleTransaction handleTransaction;

    @PostMapping ("/buy-stock")
    public ResponseDTO buyStock (@RequestParam int quantity, @RequestParam String stockSymbol, @RequestParam String investorId) {
        return handleTransaction.handleBuyingStocks(quantity, stockSymbol, investorId);
    }

    @PostMapping ("/sell-stock")
    public ResponseDTO sellStock (@RequestParam int quantity, @RequestParam String stockSymbol, @RequestParam String investorId) {
        return handleTransaction.handleSellingStocks(quantity, stockSymbol, investorId);
    }
}
